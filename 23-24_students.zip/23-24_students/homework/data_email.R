################################################################################
#                             Data Email Students                              #
################################################################################

# options ----------------------------------------------------------------------
set.seed(42)
# libraries --------------------------------------------------------------------
library(tidyverse)
library(here)
library(faux)
library(glue)
library(blastula)
library(janitor)
library(tidyverse)

# functions --------------------------------------------------------------------
rtruncnorm <- function(N, mean = 0, sd = 1, a = -Inf, b = Inf) {
  U <- runif(N, pnorm(a, mean, sd), pnorm(b, mean, sd))
  qnorm(U, mean, sd) 
}

################################################################################
# student_name <- "x"
#   tibble(
#     predictor_variable_1 = sample(c("category 1", "category 2", "category 3"), 100, replace = TRUE),
#     predictor_variable_2 = sample(c("male","female"), 100, replace = TRUE),
#     predictor_variable_3 = rtruncnorm(100, 5.33, 1.1, 1, 7),
#     outcome_variable_1 = rtruncnorm(100, 3, 2, 1, 7),
#     outcome_variable_2 = rtruncnorm(100, 4, 1, 1, 7),
#   ) |> 
#   write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
# 
# email_to <- "x@dcu.ie"
# email_body <- "
# Dear {stringr::str_to_title(student_name)}, 
# 
# I hope you are well,
# 
# On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
# MT611. During this lecture I will ask you to perform an hypothesis testing 
# analysis using the data here attached generated from the reseach paper you have 
# already sent me.
# 
# Here is the list of the variables to use for this analysis:
# 
# - outcome_variable_1 (outcome variable)
# - predictor_variable_1 (predictor variable having a main effect)
# - predictor_variable_2 (predictor variable having a main effect)
# - predictor_variable_3 (predictor variable having a main effect)
# - predictor_variable_1 & predictor_variable_2 (predictor variables having an interaction effect)
# - predictor_variable_2 & predictor_variable_3 (predictor variables having an interaction effect)
# 
# Let me know if you have any problem to download the data attached.
# 
# See you on Friday.
# 
# Best regards,
# 
# Damien"
# # compose and send email -----------------------------------------------------
# email_elements <- compose_email(body = md(glue(email_body))) |> 
#   add_attachment(
#     file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
#     filename = glue("{student_name}_data.csv")
#   )
#     
# smtp_send(
#   email_elements,
#   subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
#   from = "damien.dupre@dcu.ie",
#   to = email_to,
#   credentials = creds_key("gmail")
# )

################################################################################
student_name <- "adam"
  tibble(
    DIVERG = rnorm(6723, 1.323, 4.189),
    AGE = rnorm(6723, 24.478, 3.338),
    AGESQ = sample(c("yes", "no"), 6723, replace = TRUE),
    KEEPER = sample(c("yes", "no"), 6723, replace = TRUE),
    DEFENDER = sample(c("yes", "no"), 6723, replace = TRUE),
    MIDFIELDER = sample(c("yes", "no"), 6723, replace = TRUE),
    SAMELEAGUE = sample(c("yes", "no"), 6723, replace = TRUE),
    WINTERTW = sample(c("yes", "no"), 6723, replace = TRUE),
    ENDOFCONTRACT = sample(c("yes", "no"), 6723, replace = TRUE),
    SWAP = sample(c("yes", "no"), 6723, replace = TRUE),
    TRANSFWINDOW = sample(c("yes", "no"), 6723, replace = TRUE),
    LEAGUELEFT = sample(c("yes", "no"), 6723, replace = TRUE),
    LEAGUEJOINED = sample(c("yes", "no"), 6723, replace = TRUE),
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "adam.lynch223@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- DIVERG (outcome variable)
- AGE (predictor variable having a main effect)
- KEEPER (predictor variable having a main effect)
- SAMELEAGUE (predictor variable having a main effect)
- AGE & KEEPER (predictor variables having an interaction effect)
- KEEPER & SAMELEAGUE (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )

################################################################################
student_name <- "david"
  tibble(
    weekly_liquidity = rtruncnorm(189, 0.503, 0.128, 0.333, 0.999),
    daily_liquidity = rtruncnorm(189, 0.307, 0.122, 0.131, 0.86),
    overnight_liquidity = rtruncnorm(189, 0.255, 0.122, 0.0219, 0.778),
    perc_institutional = rtruncnorm(189, 0.407, 0.464, 0, 1),
    gross_yield = rtruncnorm(189, 20.96, 7.576, 0, 36.61),
    net_yield = rtruncnorm(189, 3.763, 4.546, 0, 23),
    fees = rtruncnorm(189, 17.2, 8.116, 0, 34.45),
    investor_turnover = rtruncnorm(189, 0.286, 0.286, 0, 1.558),
    ln_aum = rtruncnorm(189, 21.28, 1.963, 16.12, 25.53),
    avg_life_maturity = rtruncnorm(189, 61.55, 20, 2.481, 105.8),
    avg_portfolio_maturity = rtruncnorm(189, 39.92, 8.743, 2.481, 56.38),
    net_flows = rtruncnorm(189, -0.00479, 0.0154, -0.0824, 0.0378),
    external = rtruncnorm(189, 0.884, 0.322, 0, 1),
    perc_held_by_affiliates = rtruncnorm(189, 0.0802, 0.228, 0, 1)
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "david.staunton8@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- net_flows (outcome variable)
- weekly_liquidity (predictor variable having a main effect)
- perc_institutional (predictor variable having a main effect)
- gross_yield (predictor variable having a main effect)
- weekly_liquidity & perc_institutional (predictor variables having an interaction effect)
- perc_institutional & gross_yield (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )
  
################################################################################
student_name <- "eleonora"
  
tibble(
    perpetrator_type = sample(c("lone actors", "autonomous cells", "probable LA-ACs", "possible LA-AC", "known potential or possible LA-AC", "formal organizations"), 20000, replace = TRUE),
    CBRN_event_type = sample(c("Chemical", "Biological", "Radiological", "Nuclear"), 20000, replace = TRUE),
    event_type = sample(c("Protoplot", "Plot", "Attempted acquisition", "Acquisition (agent)", "Acquisition (weapon)", "Threat with possession", "Attempted use", "Use of an agent"), 20000, replace = TRUE),
    year = sample(1990:2011, 20000, replace = TRUE),
    attack_sophistication = sample(c("Low", "Medium", "High"), 20000, replace = TRUE)
  ) |> 
  count(perpetrator_type, CBRN_event_type, event_type, year, attack_sophistication) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))

email_to <- "eleonora.corsale2@mail.dcu.ie"
email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- n (outcome variable)
- perpetrator_type (predictor variable having a main effect)
- CBRN_event_type (predictor variable having a main effect)
- attack_sophistication (predictor variable having a main effect)
- perpetrator_type & CBRN_event_type (predictor variables having an interaction effect)
- CBRN_event_type & attack_sophistication (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
# compose and send email -----------------------------------------------------
email_elements <- compose_email(body = md(glue(email_body))) |> 
  add_attachment(
    file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
    filename = glue("{student_name}_data.csv")
  )

smtp_send(
  email_elements,
  subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
  from = "damien.dupre@dcu.ie",
  to = email_to,
  credentials = creds_key("gmail")
)
  
################################################################################
student_name <- "hannan"
  tibble(
    artificial_intelligence = rnorm(254, 4.15, 0.811),
    change_leadership = rnorm(254, 4.24, 0.736),
    employee_performance = rnorm(254, 4.26, 0.683),
    work_engagement = rnorm(254, 4.18, 0.782)
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "hannan.galeb2@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- employee_performance (outcome variable)
- artificial_intelligence (predictor variable having a main effect)
- change_leadership (predictor variable having a main effect)
- work_engagement (predictor variable having a main effect)
- artificial_intelligence & change_leadership (predictor variables having an interaction effect)
- change_leadership & work_engagement (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )

################################################################################
student_name <- "jacob"
  tibble(
    gender = sample(c("male","female"), 363, replace = TRUE),
    instrument = sample(1:2, 363, replace = TRUE),
    expectancy = rnorm(363, 5.40, 0.89),
    interest = rnorm(363, 5.36, 1),
    attainment = rnorm(363, 6.17, 0.7),
    utility = rnorm(363, 6.32, 1.08),
    identification = rnorm(363, 5.9, 0.82),
    self_efficacy = rnorm(363, 8.12, 1.36),
    career = rnorm(363, 6.06, 1.12)
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "jacob.baneham3@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- self_efficacy (outcome variable)
- gender (predictor variable having a main effect)
- interest (predictor variable having a main effect)
- instrument (predictor variable having a main effect)
- gender & interest (predictor variables having an interaction effect)
- interest & instrument (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )
  
################################################################################
student_name <- "mohammed"
  tibble(
    ophthalmology_subcategories = sample(c("Lens & Cataract", "External Disease & Cornea", "Glaucoma", "Neuro", "Optics", "Pathology & Tumors", "Pediatrics", "Oculoplastics", "Refractive Surgery", "Retina & Vitreous", "Intraocular Inflammation & Uveitis"), 467, replace = TRUE),
    models = sample(c("GPT-3.5", "GPT-4", "humans"), 467, replace = TRUE),
    answer = sample(0:1, 467, replace = TRUE),
    difficulty_level = sample(1:4, 467, replace = TRUE),
    anatomical_category = sample(c("anterior segment", "posterior segment", "other"), 467, replace = TRUE),
    accuracy = rnorm(467, 0.6, 0.02)
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "mohammed.sabry2@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- accuracy (outcome variable)
- models (predictor variable having a main effect)
- difficulty_level (predictor variable having a main effect)
- anatomical_category (predictor variable having a main effect)
- models & difficulty_level (predictor variables having an interaction effect)
- difficulty_level & anatomical_category (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )
  
################################################################################
student_name <- "orlaith"
  tibble(
    origin = sample(c("DCU","KU"), 542, replace = TRUE),
    student = sample(c("algebra","calculus"), 542, replace = TRUE),
    accuracy = sample(0:1, 542, replace = TRUE),
    context = sample(c("M", "P", "K"), 542, replace = TRUE),
    translation = sample(c("G -> S", "S -> G"), 542, replace = TRUE),
    function_type = sample(c("DP", "IP", "IA", "DA"), 542, replace = TRUE)
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "orlaith.condon3@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- accuracy (outcome variable)
- origin (predictor variable having a main effect)
- student (predictor variable having a main effect)
- context (predictor variable having a main effect)
- origin & student (predictor variables having an interaction effect)
- student & context (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )

################################################################################
student_name <- "tam"
  tibble(
    transparency_concern = rnorm(2612, 5.11, 1.08),
    perceived_fairness = rnorm(2612, 3.92, 1.34),
    perceived_accountability = rnorm(2612, 3.99, 1.34),
    perceived_privacy = rnorm(2612, 3.47, 1.31),
    trust = rnorm(2612, 4.17, 1.26),
    perceived_usefulness = rnorm(2612, 3.52, 1.3),
    intention_to_adopt = rnorm(2612, 3.74, 1.39)
  ) |> 
    write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "tam.nguyen25@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- intention_to_adopt (outcome variable)
- perceived_fairness (predictor variable having a main effect)
- perceived_accountability (predictor variable having a main effect)
- trust (predictor variable having a main effect)
- perceived_fairness & perceived_accountability (predictor variables having an interaction effect)
- perceived_accountability & trust (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )
  
################################################################################
student_name <- "james"
  tibble(
    organizational_identity_strength = rtruncnorm(10948, 4.20, 0.56, 1, 5),
    organizational_identification = rtruncnorm(10948, 4.26, 0.55, 1, 5),
    organizational_commitment = rtruncnorm(10948, 4.06, 0.59, 1, 5),
    turnover_intention = rtruncnorm(10948, 2.24, 0.96, 1, 5),
    subsample = sample(c("Officer", "Middle-Management", "Worker"), 10948, replace = TRUE)
  ) |> 
    write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
  email_to <- "james.redmond35@mail.dcu.ie"
  email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- turnover_intention (outcome variable)
- organizational_identity_strength (predictor variable having a main effect)
- subsample (predictor variable having a main effect)
- organizational_commitment (predictor variable having a main effect)
- organizational_identity_strength & subsample (predictor variables having an interaction effect)
- subsample & organizational_commitment (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )
  
################################################################################
student_name <- "vinicius"
  
  tibble(
    volunteers = 1:11,
    age = rnorm(11, 23.67, 0.98) |> round(0)
  ) |> 
  crossing(ogtt = c("baseline", "30min", "60min", "90min", "120min")) |> 
  crossing(condition = c("RS", "SD", "HIIT+RS", "HIIT+SD")) |> 
  mutate(
    insuline = rtruncnorm(220, 20, 10, 5, 60),
    insuline_auc = rtruncnorm(220, 100, 25, 0, 200),
    glucose = rtruncnorm(220, 100, 25, 0, 200),
    glucose_auc = rtruncnorm(220, 400, 50, 200, 600)
  ) |> 
  write_csv(here(glue("23-24_students/{student_name}/{student_name}_data.csv")))
  
email_to <- "vinicius.faria2@mail.dcu.ie"
email_body <- "
Dear {stringr::str_to_title(student_name)}, 

I hope you are well,

On Friday April 19th at 9.30am room Q305/6, we will have our last lecture of 
MT611. During this lecture I will ask you to perform an hypothesis testing 
analysis using the data here attached generated from the reseach paper you have 
already sent me.

Here is the list of the variables to use for this analysis:

- insuline (outcome variable)
- volunteers (predictor variable having a main effect)
- ogtt (predictor variable having a main effect)
- condition (predictor variable having a main effect)
- ogtt & volunteers (predictor variables having an interaction effect)
- condition & volunteers (predictor variables having an interaction effect)

Let me know if you have any problem to download the data attached.

See you on Friday.

Best regards,

Damien"
  # compose and send email -----------------------------------------------------
  email_elements <- compose_email(body = md(glue(email_body))) |> 
    add_attachment(
      file = here(glue("23-24_students/{student_name}/{student_name}_data.csv")),
      filename = glue("{student_name}_data.csv")
    )
  
  smtp_send(
    email_elements,
    subject = "MT611 - Lecture 9 on April 19th - Data and Instructions",
    from = "damien.dupre@dcu.ie",
    to = email_to,
    credentials = creds_key("gmail")
  )
  