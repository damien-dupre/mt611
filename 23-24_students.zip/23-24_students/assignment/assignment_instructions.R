# libraries --------------------------------------------------------------------
library(blastula)
library(glue)
library(here)
library(janitor)
library(tidyverse)

# variable and functions -------------------------------------------------------
email_body <- "
Dear {firstname}, 

I hope you are well,

Here are the instructions for the assignment of MT611. **Using the data that are 
attached to this email, you have to write a research paper presenting the test 
of at least 3 hypotheses.**

The data attached are real and already published from the following research 
article: {assignment_paper_url}. Read this paper and use it to formulate and test 
your hypotheses using the data attached.

This article has been selected according to its proximity to your reference 
paper submitted to me at the beginning of the module. It might not be exactly 
about your research topics, but I hope you will somehow find an interest in 
reading it. To help you in your assignment and make it easier to process, some 
variable might have been removed, variables might have been renamed, or the 
structure might have been modified.

## Assessment Requirements

The submitted research paper has to apply the following requirements:

1. It will have the __formatting style of a published PDF paper__ (see 
examples here: https://pkgs.rstudio.com/rticles/articles/examples.html),
2. It will be __no longer than 6 pages__ all included (references included, 
appendices included). Any page after the 6th page will be discarded,
3. The analysis has to include __at least 2 main effects hypotheses__ and __at 
least 1 interaction effect hypothesis__ that are tested __with only 1 
model__.
4. It will include:

  - a __short introduction__ presenting your variables and research question, 
  - a __short literature review__ with no more than 5 references to support 
your hypotheses clearly formulated at the end of this section (this literature 
review can be a short reformulation of the one published in the article where the 
data have been taken from), 
  - a __method section__  with a representation of your model and its 
corresponding equation, 
  - a __result section__ checking the conditions of application for your linear 
model as well as presenting descriptive and inferential statistics, 
  - and a __discussion/conclusion__ interpreting the results obtained in regards 
to the formulated hypotheses.

Your hypotheses can be the same than the ones formulated in the original 
article or they can be different but the model has to be a General Linear Model 
as seen during the lectures.

There is no requirement to use statistical software to perform your analyses. A 
copy-paste of the output of the r package {{report}} is recommended due to its 
performance but using Jamovi or other software is fine as well.

## Assessment Criteria

Obtaining statistically significant results (i.e., _p_ < 0.05), rather than not 
significant results, will not lead to a higher mark. The only assessment 
criteria are the following:

- Accuracy of variables, hypotheses, model, and equation description,
- Conformity of statistical analyses and results’ interpretations,
- Relevance of Tables and/or Figures,
- Overall presentation style.

I will ask you to __submit on Loop this research paper by Monday, June 24th__ at 
1 pm. No extension will be accepted due to the change with the original deadline.

Please {firstname}, can you confirm that you have read and understood the here 
above instructions and that you have received the data attached?

Best regards,

Damien"

email_body_other <- "
Dear {firstname}, 

I hope you are well,

Here are the instructions for the assignment of MT611. **Using the data that are 
attached to this email, you have to write a research paper presenting the test 
of at least 3 hypotheses.**

The data attached are real and already published from the following research 
article: {assignment_paper_url}. Read this paper and use it to formulate and test 
your hypotheses using the data attached.

## Assessment Requirements

The submitted research paper has to apply the following requirements:

1. It will have the __formatting style of a published PDF paper__ (see 
examples here: https://pkgs.rstudio.com/rticles/articles/examples.html),
2. It will be __no longer than 6 pages__ all included (references included, 
appendices included). Any page after the 6th page will be discarded,
3. The analysis has to include __at least 2 main effects hypotheses__ and __at 
least 1 interaction effect hypothesis__ that are tested __with only 1 
model__.
4. It will include:

  - a __short introduction__ presenting your variables and research question, 
  - a __short literature review__ with no more than 5 references to support 
your hypotheses clearly formulated using our templates at the end of this 
section (this literature review can be a short reformulation of the one 
published in the article where the data have been taken from), 
  - a __method section__ with a representation of your model and its 
corresponding equation, 
  - a __result section__ checking the conditions of application for your linear 
model as well as presenting descriptive and inferential statistics using the 
relevant communication format, 
  - and a __discussion/conclusion__ interpreting the results obtained in regards 
to the formulated hypotheses.

Your hypotheses can be the same than the ones formulated in the original 
article or they can be different but the model has to be a General Linear Model 
as seen during the lectures.

There is no requirement to use statistical software to perform your analyses. A 
copy-paste of the output of the r package {{report}} is recommended due to its 
performance but using Jamovi or other software is fine as well.

## Assessment Criteria

Obtaining statistically significant results (i.e., _p_ < 0.05), rather than not 
significant results, will not lead to a higher mark. The only assessment 
criteria are the following:

- Accuracy of variables, hypotheses, model, and equation description,
- Conformity of statistical analyses and results’ interpretations,
- Relevance of Tables and/or Figures,
- Overall presentation style.

I will ask you to __submit on Loop this research paper by Monday, June 24th__ at 
1 pm. No extension will be accepted due to the change with the original deadline.

Please {firstname}, can you confirm that you have read and understood the here 
above instructions and that you have received the data attached?

Best regards,

Damien"

# test emails ------------------------------------------------------------------
data_students <- 
  tibble(
    firstname = c("Damien", "Test1", "Test2"),
    email = c("damien.dupre@dcu.ie", "test.1@gmail.com", "test.2@gmail.com"),
    assignment_paper_url = c("paper 0", "paper 2", "paper 2")
  ) # check in email sent box if they have been successfully sent 

# data student -----------------------------------------------------------------
data_students <- file.choose() |>  
  read_csv() |> 
  clean_names()

################################################################################
data_students |>
  mutate(
    email_content = if_else(tailored_data == 1, glue(email_body), glue(email_body_other)),
    email_send = map2(
      .x = email, 
      .y = email_content, 
      ~smtp_send(
        compose_email(body = md(.y)) |> 
          add_attachment(file = here(glue("23-24_students/assignment/assignment_data/{str_extract(string = .x, pattern = '[^.]+')}/data.csv"))),
        subject = "MT611 - Assignment Instructions and Data - Confirm Reception",
        from = "damien.dupre@dcu.ie",
        to = .x,
        credentials = creds_key("gmail")
      )
    )
  )
