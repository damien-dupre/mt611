################################################################################
#                        Data Simulation Students                              #
################################################################################

# options ----------------------------------------------------------------------
set.seed(42)
# libraries --------------------------------------------------------------------
library(tidyverse)
library(tabulizer)
library(here)
library(janitor)
library(snakecase)
library(faux)
library(magrittr)
# functions --------------------------------------------------------------------
rtruncnorm <- function(N, mean = 0, sd = 1, a = -Inf, b = Inf) {
  U <- runif(N, pnorm(a, mean, sd), pnorm(b, mean, sd))
  qnorm(U, mean, sd) 
}

# Aisling ######################################################################
aisling_data <- 
  tibble(
    valr = rtruncnorm(100, 15, 3, -3, 38.7),
    vilr = rtruncnorm(100, 15, 3, -3.1, 35.3),
    vsil = rtruncnorm(100, 15, 3, -10.1, 43.5),
    runners_health_group = sample(c("Healthy controls","Grouped injury"), 100, replace = TRUE, prob = c(59.7, 40.3))
  ) |> 
  write_csv(here("21-22_students/data/aisling_data.csv"))
  

# Anna #########################################################################
anna_data <- 
  tibble(
    social_presence = rtruncnorm(100, 4.17, 0.30, 1, 7),
    immersion = rtruncnorm(100, 3.01, 0.47, 1, 7),
    shared_understanding = rtruncnorm(100, 4.27, 0.041, 1, 7),
    efficiency = rtruncnorm(100, 3.5, 1, 1, 7),
    consensus = rtruncnorm(100, 6.63, 0.42, 1, 7),
    process_satisfaction = rtruncnorm(100, 4.35, 0.31, 1, 7),
    outcome_satisfaction = rtruncnorm(100, 4.53, 0.4, 1, 7),
    cohesion = rtruncnorm(100, 3.53, 0.4, 1, 7),
    condition = sample(c("CMC","VE", "VDR"), 100, replace = TRUE)
  ) |> 
  mutate(
    experimental_condition = case_when(
      condition == "CMC" ~ -1,
      condition == "VE" ~ 1,
      condition == "VDR" ~ 1
    ),
    virtual_condition = case_when(
      condition == "CMC" ~ 0,
      condition == "VE" ~ -1,
      condition == "VDR" ~ 1
    )
  ) |> 
  write_csv(here("21-22_students/data/anna_data.csv"))

# Calvin #######################################################################
calvin_data <- 
  tibble(
    eccentric_hamstring_strength_start_preseason = rtruncnorm(100, 250, 20, 160, 384),
    eccentric_hamstring_strength_end_preseason = rtruncnorm(100, 250, 20, 207, 403),
    eccentric_hamstring_strength_in_season = rtruncnorm(100, 250, 20, 99, 463),
    hsi = sample(c("yes","no"), 100, replace = TRUE, prob = c(50, 50)),
    age = rtruncnorm(100, 23.3, 3.7),
    height = rtruncnorm(100, 188, 7.2),
    weight = rtruncnorm(100, 87.3, 8.2)
  ) |> 
  write_csv(here("21-22_students/data/calvin_data.csv"))

# Hayley #######################################################################
hayley_data <- 
  tibble(
    gender = sample(c("male","female"), 100, replace = TRUE, prob = c(50, 50)),
    id_group = sample(c("2013","2017"), 100, replace = TRUE, prob = c(50, 50)),
    intellectual_disability = sample(c("with","without"), 100, replace = TRUE, prob = c(50, 50)),
    tgmd = rtruncnorm(100, 50, 20, 0, 100),
    run = sample(0:5, 100, replace = TRUE),
    gallop = sample(0:5, 100, replace = TRUE),
    hop = sample(0:4, 100, replace = TRUE),
    skip = sample(0:4, 100, replace = TRUE),
    horizontal_jump = sample(0:4, 100, replace = TRUE),
    slide = sample(0:5, 100, replace = TRUE),
    two_hand_strike = sample(0:5, 100, replace = TRUE),
    one_hand_strike = sample(0:4, 100, replace = TRUE),
    stationary_dribble = sample(0:3, 100, replace = TRUE),
    catch = sample(0:3, 100, replace = TRUE),
    kick = sample(0:4, 100, replace = TRUE),
    overhand_throw = sample(0:4, 100, replace = TRUE),
    underhand_throw = sample(0:5, 100, replace = TRUE)
  ) |> 
  rowwise() |> 
  mutate(
    locomotor_skills = sum(run,gallop,hop,skip,horizontal_jump,slide),
    ball_skills = sum(two_hand_strike,one_hand_strike,stationary_dribble,catch,kick,overhand_throw,underhand_throw)
  ) |> 
  ungroup() |> 
  write_csv(here("21-22_students/data/hayley_data.csv"))

# Maria ########################################################################
maria_data <- read_csv("/Users/damiendcu/OneDrive/Projects/mt611/21-22_students/Wards_Names_and_Codes_in_England_and_Wales.csv") |> 
  expand_grid(
    gender = c("male", "female"),
    age = c("15-24", "25-44"),
    time = c(1981, 1998)
  ) |>
  mutate(
    pop_density = rtruncnorm(70400, 920, 100, 2, 21646),
    pop_potential = rtruncnorm(70400, 448, 100, 123, 1152),
    suicide_rate = rtruncnorm(70400, 5, 1, 1, 25),
    quartile_ward = sample(1:4, 70400, replace = TRUE)
  ) |> 
  write_csv(here("21-22_students/data/maria_data.csv"))

# Nina #########################################################################
nina_data <- 
  tibble(
    nursing_classes = sample(c("Prenursing","Senior BSN", "MSN"), 100, replace = TRUE),
    age = rtruncnorm(100, 23.37, 7.19, 18, 56) |> round(0),
    gender = sample(c("male","female"), 100, replace = TRUE, prob = c(50, 50)),
    previous_cultural_awareness_course = sample(c("None","Cultural diversity course", "Global health course", "Both courses"), 100, replace = TRUE),
    general_attitudes = rtruncnorm(100, 5.41, 0.58, 1, 7),
    research_attitudes = rtruncnorm(100, 5.46, 1.06, 1, 7),
    clinical_experience = rtruncnorm(100, 5.83, 0.96, 1, 7)
  ) |> 
  write_csv(here("21-22_students/data/nina_data.csv"))

# Paolo ########################################################################
paolo_data <- 
  tibble(
    age = rtruncnorm(100, 38.7, 10.4, 18, 65) |> round(0),
    gender = sample(c("male","female"), 100, replace = TRUE, prob = c(43, 57)),
    dyadic_tenure = rtruncnorm(100, 6.52, 6.3, 1, 20) |> round(0),
    education = rtruncnorm(100, 3.08, 0.75, 1, 7) |> round(0),
    coworker_political_skill = rtruncnorm(100, 5.6, 0.88, 1, 7),
    employee_task_performance = rtruncnorm(100, 5.76, 1.08, 1, 7),
    employee_political_skill = rtruncnorm(100, 5.54, 0.9, 1, 7),
    rivalry = rtruncnorm(100, 4.59, 1.83, 1, 7),
    coworker_perception_of_status_threat = rtruncnorm(100, 2.74, 1.33, 1, 7),
    coworker_social_undermining = rtruncnorm(100, 3.18, 2.08, 1, 7)
  ) |> 
  write_csv(here("21-22_students/data/paolo_data.csv"))

# Sean #########################################################################
sean_data <- 
  tibble(
    job = sample(c("central","peripheral"), 100, replace = TRUE),
    degree_match = sample(c(1, 3, 5), 100, replace = TRUE),
    applicant_age = sample(c("young","old"), 100, replace = TRUE),
    applicant_gender = sample(c("male","female"), 100, replace = TRUE),
    suitability_score = rtruncnorm(100, 5, 2, 1, 7),
    applicant_rating_time = rtruncnorm(100, 17.5, 0.1, 16.79, 18.36),
    applicant_review_time = rtruncnorm(100, 10, 0.1, 9.91, 11.59)
  ) |> 
  write_csv(here("21-22_students/data/sean_data.csv"))

# Shauna #######################################################################
shauna_data <- 
  tibble(
    intervention_time = sample(c("before","after"), 100, replace = TRUE),
    patient_group = sample(c("control","prehabilitation"), 100, replace = TRUE),
    CCET = rtruncnorm(100, 350, 15, 226.40, 571.83),
    arm_curl = rtruncnorm(100, 15, 1, 10.4, 20.8),
    chair_to_stand = rtruncnorm(100, 12.5, 1, 8.8, 15.2),
    `6MWT` = rtruncnorm(100, 400, 10, 303.9, 516.7)
  ) |> 
  write_csv(here("21-22_students/data/shauna_data.csv"))

# Siobhan ######################################################################
siobhan_data <- 
  tibble(
    resource_condition = sample(c("No social resources", "No financial resources", "Social and financial resources"), 100, replace = TRUE),
    gender = sample(c("male","female"), 100, replace = TRUE),
    perceived_precariousness = rtruncnorm(100, 5.33, 1.1, 1, 7),
    position_evaluation = rtruncnorm(100, 3, 2, 1, 7),
    anticipated_acceptance = rtruncnorm(100, 4, 1, 1, 7),
    anticipated_influence = rtruncnorm(100, 3.5, 2, 1, 7)
  ) |> 
  write_csv(here("21-22_students/data/siobhan_data.csv"))

# Tara #########################################################################
tara_data <- 
  tibble(
    aging_time = sample(c(0, 432, 1296, 1728, 2160), 100, replace = TRUE),
    carbonyl_index = rtruncnorm(100, 0.7, 0.01, 0.4, 0.9),
    contact_angle = rtruncnorm(100, 70, 10, 50, 110),
    tan_delta = rtruncnorm(100, 0.02, 0.001, 0.014, 0.024),
    surface_resistance = rtruncnorm(100, 1250, 10, 1200, 1300),
    oc = rtruncnorm(100, 1.5, 0.1, 0.5, 3)
  ) |> 
  write_csv(here("21-22_students/data/tara_data.csv"))

