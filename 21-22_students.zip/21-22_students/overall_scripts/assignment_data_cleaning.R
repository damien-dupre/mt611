# libraries --------------------------------------------------------------------
library(janitor)
library(here)
library(tidyverse)

# aisling ----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/aisling/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  filter(trial == 1, task < 3) |> 
  select(flooring, shoe, task, vilr) |> 
  mutate(
    flooring = case_when(
      flooring == 1 ~ "sf0",
      flooring == 2 ~ "sf1",
      flooring == 3 ~ "sf2",
      flooring == 4 ~ "sf3",
      flooring == 5 ~ "sf4"
      ),
    shoe = case_when(
      shoe == 1 ~ "min",
      shoe == 2 ~ "cush"
    ),
    task = case_when(
      task == 1 ~ "ankle",
      task == 2 ~ "multi"
    )
  ) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/aisling/mt611_assignment_data_cleaned.csv"))

# anna -------------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/anna/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  select(display = cond_vr, familiarity = fam_no, vr_experience_level = vr_times, response_time = rt) |> 
  mutate(
    display = case_when(
      display == 0 ~ "desktop_monitor",
      display == 1 ~ "virtual_reality"
    ),
    familiarity = case_when(
      familiarity == 0 ~ "unfamiliar",
      familiarity == 1 ~ "familiar"
    )
  ) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/anna/mt611_assignment_data_cleaned.csv"))

# calvin -----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/calvin/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  pivot_longer(cols = x5m:x20m, names_to = "sprint_test", values_to = "sprint_performance") |> 
  select(group, condition, sprint_test, sprint_performance) |> 
  mutate(
    group = case_when(
      group == "CG" ~ "control",
      group == "NG1" ~ "nordic_1",
      group == "NG2" ~ "nordic_2"
    ),
    condition = tolower(condition)
  ) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/calvin/mt611_assignment_data_cleaned.csv"))

# daniel -----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/daniel/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  select(is01:bp07) |> 
  rowwise() |> 
  transmute(
    business_performance = mean(c_across(starts_with("bp")), na.rm = TRUE),
    inbound_sustainability = mean(c_across(starts_with("is")), na.rm = TRUE),
    outbound_sustainability = mean(c_across(starts_with("os")), na.rm = TRUE),
    internal_sustainability = mean(c_across(starts_with("in")), na.rm = TRUE),
  ) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/daniel/mt611_assignment_data_cleaned.csv"))

# hayley -----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/hayley/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  select(
    body_mass_index = bmi,
    tgmd2_locomotor_skills = loc_ss,
    tgmd2_objectcontrol_skills = ocss,
    perceived_motor_competence = perc_mc
  ) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/hayley/mt611_assignment_data_cleaned.csv"))

# nipuna -----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/nipuna/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |>
  rowwise() |> 
  mutate(
    origin = case_when(nativity == 1 ~ "native", nativity == 2 ~ "foreign"),
    cross_cultural_empathy = mean(c_across(starts_with("e_")), na.rm = TRUE),
    cross_cultural_skills = mean(c_across(starts_with("s_")), na.rm = TRUE),
    psychological_distress = mean(c_across(starts_with("ghq_")), na.rm = TRUE)
  ) |> 
  drop_na() |> 
  select(origin, cross_cultural_empathy, cross_cultural_skills, psychological_distress) |> 
  write_csv(here("21-22_students/assignment/nipuna/mt611_assignment_data_cleaned.csv"))

# paolo ------------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/paolo/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  mutate(friend_side = case_when(friend_side == 0 ~ "no", friend_side == 1 ~ "yes")) |> 
  select(-id, -female, -age) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/paolo/mt611_assignment_data_cleaned.csv"))

# sean -------------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/sean/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  pivot_longer(b_f_heavy:c_m_original, names_to = "condition", values_to = "hiring_rating") |> 
  separate(condition, into = c("stimulus_job", "stimulus_sex", "stimulus_bmi")) |> 
  mutate(stimulus_job = case_when(stimulus_job == "b" ~ "non_customer_facing", stimulus_job == "c" ~ "customer_facing")) |> 
  select(-id, -part_sex) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/sean/mt611_assignment_data_cleaned.csv"))

# shauna -----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv2(here("21-22_students/assignment/shauna/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  select(age = age_years, bmi, pre_lvef_simpson_percent = pre_lvef_simpson_important_for_euro_score_norm_55_percent_mild_45_percent_moderate_35_percent_severe_25_percent, post_lvef_simpson_percent) |> 
  pivot_longer(cols = c(pre_lvef_simpson_percent, post_lvef_simpson_percent), names_to = "period", values_to = "lvef_simpson_percent") |> 
  mutate(period = str_remove(period, "_lvef_simpson_percent")) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/shauna/mt611_assignment_data_cleaned.csv"))

# siobhan ----------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/siobhan/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  select(crisis_type = ce_3cris, roberto_adecuado_1, isabel_adecuado_1, javier_adecuado_1, maria_adecuado_1) |> 
  pivot_longer(-crisis_type, names_to = "candidates", values_to = "good_manager_for_the_company") |> 
  mutate(
    candidate_gendered_traits = case_when(
      candidates == "roberto_adecuado_1" ~ "agentic",
      candidates == "isabel_adecuado_1" ~ "agentic",
      candidates == "javier_adecuado_1" ~ "communal",
      candidates == "maria_adecuado_1" ~ "communal"
    ),
    candidate_gender = case_when(
      candidates == "roberto_adecuado_1" ~ "male",
      candidates == "isabel_adecuado_1" ~ "female",
      candidates == "javier_adecuado_1" ~ "male",
      candidates == "maria_adecuado_1" ~ "female"
    ),
    crisis_type = case_when(
      crisis_type == 1 ~ "financial",
      crisis_type == 2 ~ "relational",
      crisis_type == 3 ~ "no_crisis"
    )
  ) |> 
  select(-candidates) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/siobhan/mt611_assignment_data_cleaned.csv"))

# tara -------------------------------------------------------------------------
mt611_assignment_data_original <- read_csv(here("21-22_students/assignment/tara/mt611_assignment_data_original.csv"))

mt611_assignment_data_cleaned <- mt611_assignment_data_original |> 
  clean_names() |> 
  select(time, mass_loss, polymer, pH = p_h) |> 
  drop_na() |> 
  write_csv(here("21-22_students/assignment/tara/mt611_assignment_data_cleaned.csv"))
