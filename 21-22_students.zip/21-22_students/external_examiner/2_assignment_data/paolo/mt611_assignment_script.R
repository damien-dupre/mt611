library(haven)
library(tidyverse)

Survey_M1_NOV282016.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/Survey_M1_NOV282016.dta")
Survey_M2_NOV292016.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/Survey_M2_NOV292016.dta")
Survey_M3_DEC012016.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/Survey_M3_DEC012016.dta")
X1X2X3_ID_ASSIGNEDPOS_NOV232016_2.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_ID_ASSIGNEDPOS_NOV232016_2.dta")
X1X2X3_ID_WORKEDPOS_NOV232016_2.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_ID_WORKEDPOS_NOV232016_2.dta")
X1X2X3_NEWID_DEC022016.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_NEWID_DEC022016.dta")
X1X2X3_POS_TABLEPAIR.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_POS_TABLEPAIR.dta")
X1X2X3_PRIOR_ID_WORKEDPOS.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_PRIOR_ID_WORKEDPOS.dta")
X1X2X3_PRIOR_POS_TABLEPAIR.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_PRIOR_POS_TABLEPAIR.dta")
X1X2X3_PRIOR_WORKREPORT_DEC052016.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_PRIOR_WORKREPORT_DEC052016.dta")
X1X2X3_WORKREPORT_DEC052016.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1X2X3_WORKREPORT_DEC052016.dta")
X1_NEWID.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X1_NEWID.dta")
X2_NEWID.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X2_NEWID.dta")
X3_NEWID.dta <- read_dta("/Users/damiendcu/Downloads/116347-V1/data/X3_NEWID.dta")

friend_df <- Survey_M2_NOV292016.dta |>
  drop_na(friendid) |> 
  select(id, friendid) |> 
  mutate(is_friend = "yes")

prod_df <- X1X2X3_WORKREPORT_DEC052016.dta |> 
  # slice_max(date) |> 
  # filter(attend == 1) |> 
  identity()

table_df <- X1X2X3_POS_TABLEPAIR.dta |> 
  mutate(alongside1 = case_when(
    group == 1 & num_position == 2 ~ 01 ,
    group == 2 & num_position == 2 ~ 01 ,
    group == 3 & num_position == 2 ~ 01 ,
    group == 1 & num_position == 11 ~ 10 ,
    group == 2 & num_position == 11 ~ 10 ,
    group == 3 & num_position == 17 ~ 10 ,
    group == 3 & num_position == 9 ~ 10 ,
    group == 1 & num_position == 10 ~ 11 ,
    group == 1 & num_position == 12 ~ 11 ,
    group == 2 & num_position == 10 ~ 11 ,
    group == 2 & num_position == 12 ~ 11 ,
    group == 3 & num_position == 12 ~ 11 ,
    group == 1 & num_position == 25 ~ 12 ,
    group == 2 & num_position == 19 ~ 12 ,
    group == 3 & num_position == 19 ~ 12 ,
    group == 1 & num_position == 14 ~ 13 ,
    group == 2 & num_position == 14 ~ 13 ,
    group == 3 & num_position == 14 ~ 13 ,
    group == 1 & num_position == 13 ~ 14 ,
    group == 1 & num_position == 15 ~ 14 ,
    group == 2 & num_position == 21 ~ 14 ,
    group == 3 & num_position == 21 ~ 14 ,
    group == 1 & num_position == 27 ~ 15 ,
    group == 2 & num_position == 16 ~ 15 ,
    group == 3 & num_position == 16 ~ 15 ,
    group == 1 & num_position == 17 ~ 16 ,
    group == 2 & num_position == 24 ~ 16 ,
    group == 3 & num_position == 23 ~ 16 ,
    group == 1 & num_position == 16 ~ 17 ,
    group == 1 & num_position == 18 ~ 17 ,
    group == 2 & num_position == 18 ~ 17 ,
    group == 3 & num_position == 18 ~ 17 ,
    group == 1 & num_position == 29 ~ 18 ,
    group == 2 & num_position == 27 ~ 18 ,
    group == 3 & num_position == 25 ~ 18 ,
    group == 1 & num_position == 20 ~ 19 ,
    group == 2 & num_position == 20 ~ 19 ,
    group == 3 & num_position == 20 ~ 19 ,
    group == 1 & num_position == 1 ~ 02 ,
    group == 1 & num_position == 3 ~ 02 ,
    group == 2 & num_position == 1 ~ 02 ,
    group == 2 & num_position == 3 ~ 02 ,
    group == 3 & num_position == 1 ~ 02 ,
    group == 3 & num_position == 3 ~ 02 ,
    group == 1 & num_position == 31 ~ 20 ,
    group == 2 & num_position == 30 ~ 20 ,
    group == 1 & num_position == 22 ~ 21 ,
    group == 2 & num_position == 22 ~ 21 ,
    group == 3 & num_position == 22 ~ 21 ,
    group == 1 & num_position == 33 ~ 22 ,
    group == 2 & num_position == 23 ~ 22 ,
    group == 1 & num_position == 24 ~ 23 ,
    group == 2 & num_position == 33 ~ 23 ,
    group == 3 & num_position == 24 ~ 23 ,
    group == 1 & num_position == 35 ~ 24 ,
    group == 2 & num_position == 25 ~ 24 ,
    group == 1 & num_position == 26 ~ 25 ,
    group == 2 & num_position == 26 ~ 25 ,
    group == 3 & num_position == 26 ~ 25 ,
    group == 1 & num_position == 37 ~ 26 ,
    group == 2 & num_position == 35 ~ 26 ,
    group == 1 & num_position == 28 ~ 27 ,
    group == 2 & num_position == 28 ~ 27 ,
    group == 1 & num_position == 39 ~ 28 ,
    group == 2 & num_position == 29 ~ 28 ,
    group == 1 & num_position == 30 ~ 29 ,
    group == 2 & num_position == 37 ~ 29 ,
    group == 1 & num_position == 19 ~ 03 ,
    group == 2 & num_position == 13 ~ 03 ,
    group == 3 & num_position == 11 ~ 03 ,
    group == 1 & num_position == 41 ~ 30 ,
    group == 2 & num_position == 31 ~ 30 ,
    group == 1 & num_position == 32 ~ 31 ,
    group == 2 & num_position == 32 ~ 31 ,
    group == 2 & num_position == 39 ~ 32 ,
    group == 1 & num_position == 34 ~ 33 ,
    group == 2 & num_position == 34 ~ 33 ,
    group == 1 & num_position == 36 ~ 35 ,
    group == 2 & num_position == 36 ~ 35 ,
    group == 1 & num_position == 38 ~ 37 ,
    group == 2 & num_position == 38 ~ 37 ,
    group == 1 & num_position == 40 ~ 39 ,
    group == 2 & num_position == 40 ~ 39 ,
    group == 1 & num_position == 5 ~ 04 ,
    group == 2 & num_position == 5 ~ 04 ,
    group == 3 & num_position == 5 ~ 04 ,
    group == 1 & num_position == 42 ~ 41 ,
    group == 1 & num_position == 4 ~ 05 ,
    group == 1 & num_position == 6 ~ 05 ,
    group == 2 & num_position == 4 ~ 05 ,
    group == 2 & num_position == 6 ~ 05 ,
    group == 3 & num_position == 4 ~ 05 ,
    group == 3 & num_position == 6 ~ 05 ,
    group == 1 & num_position == 21 ~ 06 ,
    group == 2 & num_position == 15 ~ 06 ,
    group == 3 & num_position == 13 ~ 06 ,
    group == 1 & num_position == 8 ~ 07 ,
    group == 2 & num_position == 8 ~ 07 ,
    group == 3 & num_position == 8 ~ 07 ,
    group == 1 & num_position == 7 ~ 08 ,
    group == 1 & num_position == 9 ~ 08 ,
    group == 2 & num_position == 7 ~ 08 ,
    group == 2 & num_position == 9 ~ 08 ,
    group == 3 & num_position == 15 ~ 08 ,
    group == 3 & num_position == 7 ~ 08 ,
    group == 1 & num_position == 23 ~ 09 ,
    group == 2 & num_position == 17 ~ 09 ,
    group == 3 & num_position == 10 ~ 09
  )) |> 
  mutate(alongside2 = case_when(
    group == 3 & num_position == 3 ~ 11,
    group == 1 & num_position == 11 ~ 12,
    group == 2 & num_position == 11 ~ 12,
    group == 3 & num_position == 11 ~ 12,
    group == 2 & num_position == 3 ~ 13,
    group == 3 & num_position == 6 ~ 13,
    group == 2 & num_position == 13 ~ 14,
    group == 3 & num_position == 13 ~ 14,
    group == 1 & num_position == 14 ~ 15,
    group == 2 & num_position == 6 ~ 15,
    group == 3 & num_position == 8 ~ 15,
    group == 2 & num_position == 15 ~ 16,
    group == 3 & num_position == 15 ~ 16,
    group == 2 & num_position == 9 ~ 17,
    group == 3 & num_position == 10 ~ 17,
    group == 1 & num_position == 17 ~ 18,
    group == 2 & num_position == 17 ~ 18,
    group == 3 & num_position == 17 ~ 18,
    group == 1 & num_position == 3 ~ 19,
    group == 2 & num_position == 12 ~ 19,
    group == 3 & num_position == 12 ~ 19,
    group == 1 & num_position == 19 ~ 20,
    group == 2 & num_position == 19 ~ 20,
    group == 3 & num_position == 19 ~ 20,
    group == 1 & num_position == 6 ~ 21,
    group == 2 & num_position == 14 ~ 21,
    group == 3 & num_position == 14 ~ 21,
    group == 1 & num_position == 21 ~ 22,
    group == 2 & num_position == 21 ~ 22,
    group == 3 & num_position == 21 ~ 22,
    group == 1 & num_position == 9 ~ 23,
    group == 2 & num_position == 22 ~ 23,
    group == 3 & num_position == 16 ~ 23,
    group == 1 & num_position == 23 ~ 24,
    group == 2 & num_position == 16 ~ 24,
    group == 3 & num_position == 23 ~ 24,
    group == 1 & num_position == 12 ~ 25,
    group == 2 & num_position == 24 ~ 25,
    group == 3 & num_position == 18 ~ 25,
    group == 1 & num_position == 25 ~ 26,
    group == 2 & num_position == 25 ~ 26,
    group == 3 & num_position == 25 ~ 26,
    group == 1 & num_position == 15 ~ 27,
    group == 2 & num_position == 18 ~ 27,
    group == 1 & num_position == 27 ~ 28,
    group == 2 & num_position == 27 ~ 28,
    group == 1 & num_position == 18 ~ 29,
    group == 2 & num_position == 28 ~ 29,
    group == 1 & num_position == 2 ~ 03,
    group == 2 & num_position == 2 ~ 03,
    group == 3 & num_position == 2 ~ 03,
    group == 1 & num_position == 29 ~ 30,
    group == 2 & num_position == 20 ~ 30,
    group == 1 & num_position == 20 ~ 31,
    group == 2 & num_position == 30 ~ 31,
    group == 1 & num_position == 31 ~ 32,
    group == 2 & num_position == 31 ~ 32,
    group == 1 & num_position == 22 ~ 33,
    group == 2 & num_position == 23 ~ 33,
    group == 1 & num_position == 33 ~ 34,
    group == 2 & num_position == 33 ~ 34,
    group == 1 & num_position == 24 ~ 35,
    group == 2 & num_position == 26 ~ 35,
    group == 1 & num_position == 35 ~ 36,
    group == 2 & num_position == 35 ~ 36,
    group == 1 & num_position == 26 ~ 37,
    group == 2 & num_position == 29 ~ 37,
    group == 1 & num_position == 37 ~ 38,
    group == 2 & num_position == 37 ~ 38,
    group == 1 & num_position == 28 ~ 39,
    group == 2 & num_position == 32 ~ 39,
    group == 1 & num_position == 39 ~ 40,
    group == 2 & num_position == 39 ~ 40,
    group == 1 & num_position == 30 ~ 41,
    group == 1 & num_position == 41 ~ 42,
    group == 1 & num_position == 5 ~ 06,
    group == 2 & num_position == 5 ~ 06,
    group == 3 & num_position == 5 ~ 06,
    group == 1 & num_position == 8 ~ 09,
    group == 2 & num_position == 8 ~ 09
  ))

prod_table_df <- left_join(prod_df, table_df)

position_alongside1_df <- prod_df |> 
  select(date, group, alongside1 = num_position, id_alongside1 = id) 

position_alongside2_df <- prod_df |> 
  select(date, group, alongside2 = num_position, id_alongside2 = id) 

position_alongside_df <- prod_table_df |> 
  left_join(position_alongside1_df, by = c("date", "group", "alongside1")) |> 
  left_join(position_alongside2_df, by = c("date", "group", "alongside2"))

position_alongside_friend <- position_alongside_df |> 
  left_join(friend_df, by = c("id", "id_alongside1" = "friendid")) |> 
  rename(is_alongside1_friend = is_friend) |> 
  left_join(friend_df, by = c("id", "id_alongside2" = "friendid")) |> 
  rename(is_alongside2_friend = is_friend) |> 
  left_join(Survey_M3_DEC012016.dta, by = "id") |> 
  mutate(
    productivity_percent = (work/mins) * 100,
    friend_side = case_when(
      is_alongside1_friend == "yes" & is_alongside2_friend == "yes" ~ 2,
      is.na(is_alongside1_friend) & is_alongside2_friend == "yes" ~ 1,
      is_alongside1_friend == "yes" & is.na(is_alongside2_friend) ~ 1,
      is.na(is_alongside1_friend) & is.na(is_alongside2_friend) ~ 0
    )
  ) |> 
  left_join(Survey_M1_NOV282016.dta, by = "id") |> 
  drop_na(productivity_percent) |> 
  select(id, female, age, conscientiousness, neuroticism, productivity_percent, friend_side) |> 
  write_csv("mt611_assignment_data.csv")
  


 
  