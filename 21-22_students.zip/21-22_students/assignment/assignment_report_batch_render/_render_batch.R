################################################################################
#                  Automatic Processing of Assignments' Feedback               #
################################################################################
# libraries --------------------------------------------------------------------
library(blastula)
library(glue)
library(here)
library(rmarkdown)
library(tidyverse)

# data feedback ----------------------------------------------------------------
student_data <- 
  read_csv(
    here("21-22_students/assignment/students_comments.csv"),
    locale = locale(encoding = "UTF-8")
  )


# pdf feedback -----------------------------------------------------------------
walk(
  .x = student_data$student_fullname,
  ~ render(
    input = here("21-22_students/assignment/assignment_report_batch_render/index.Rmd"),
    output_file = glue(here("21-22_students/assignment/assignment_feedback/mt611_{.x}_assignment_feedback.pdf")),
    params = list(student_fullname = {.x})
  )
)

# email feedback ---------------------------------------------------------------
email_content <- "
Dear {Firstname}, 

Many thanks for your work on the MT611 assignment. I know that statistics can be 
complicated, especially after being introduced to new concepts, tools, and to a 
new coding language. I also know that these data were changing, not only because 
they are not yours but also because  their are real data. As such, they were 
obtained from {assignment_paper_url} and can be found at the following url: 
{assignment_data_url}. I would strongly suggest to have a look at the results 
obtained in this source and if you find your results interesting enough compared 
to what has been found, you can try to publish the results youhave obtained or 
to present them in a conference. Don't hesitate to tell me and I will be happy 
to help you to acheive this goal.

The main purpose of this document is to give you some feedback on the form and 
on the content of your assignment.

## Assignment Form and Design

{assignment_form}

## Assignment Content

{assignment_content}

## Assignment Evaluation

With all these points taken into account it appears that your assignment is 
showning a very good quality and I happy to make you PASS this module (the 
module is PASS or FAIL only, no mark is given).

I hope you enjoy this module and that statistics are not a challenge for you any 
more. 

Good luck for your future research.

Kind regards.

Damien"

send_email <- function(email_body, email_address, email_attachment) {
  compose_email(body = md(email_body)) |> 
    add_attachment(file = email_attachment) |> 
    smtp_send(
      subject = "MT611 - Assignment Comments and Feedback",
      from = "damien.dupre@dcu.ie",
      to = email_address,
      credentials = creds_key("gmail")
  )
}

student_data |> 
  mutate(
    email_body = glue(email_content),
    email_attachment = glue("/Users/damienhome/Library/CloudStorage/OneDrive-Personal/Projects/mt611/21-22_students/assignment/assignment_submitted/{student_fullname}_assignsubmission_file_/assignment_with_comment.pdf")
  ) |> 
  select(email_body, email_address, email_attachment) |> 
  pmap(send_email)
