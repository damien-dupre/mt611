# libraries --------------------------------------------------------------------
library(blastula)
library(glue)
library(here)
library(janitor)
library(tidyverse)

# variable and functions -------------------------------------------------------
email_body <- "
Dear {firstname}, 

I hope you are well,

For the assignment of MT611, I will ask you to __submit on Loop a research 
paper using the attached data by Tuesday, June 21st__ at 1 pm.

The data attached are real and already published data from the following 
article: {assignment_paper_url}. This article has been selected according to its 
proximity to your reference paper submitted to me at the beginning of the 
module. The raw data are also available here: {assignment_data_url}. To help you 
in your assignment, only 4 variables have been kept in the data attached. In 
addition, the variables have been renamed and recoded with explicit labels.

The submitted research paper has to apply the following requirements:

1. It will have the __formatting style of a published PDF paper__ (see 
examples here: https://pkgs.rstudio.com/rticles/articles/examples.html),
2. It will be __no longer than 6 pages__ all included (references included, 
appendices included). Any page after the 6th page will be discarded,
3. The analysis has to include __at least 3 main effects hypotheses__ and __at 
least 1 interaction effect hypothesis__ that are tested __with only 1 
model__.
4. It will include:

  - a __short introduction__ presenting your variables and research question, 
  - a __short literature review__ with no more than 5 references to support 
your hypotheses clearly formulated at the end of this section (this literature 
review can be a short reformulation of the one published in the paper where the 
data have been taken from), 
  - a __method section__  with a representation of your model and its 
corresponding equation, 
  - a __result section__ checking the conditions of application for your linear 
model as well as presenting descriptive and inferential statistics, 
  - and a __discussion/conclusion__ interpreting the results obtained in regards 
to the formulated hypotheses.

Your hypotheses can be the same than the ones formulated in the orginal 
paper or they can be different.

There is no requirement to use statistical software to perform your 
analyses. A copy-paste of the output of the r package {{report}} is recommended 
due to its performance but using Jamovi or other software is fine as well.

## Assessment Criteria

Obtaining statistically significant results (i.e., _p_ < 0.05), rather than not 
significant results, will not lead to a higher mark. The only assessment 
criteria are the following:

- Accuracy of variables, hypotheses, model, and equation description,
- Conformity of statistical analyses and results’ interpretations,
- Relevance of Tables and/or Figures,
- Overall presentation style.

Please {firstname}, can you confirm that you have read and understood the here 
above instructions and that you have received the data attached?

Best regards,

Damien"

# test emails ------------------------------------------------------------------
data_students <- 
  tibble(
    firstname = c("Damien", "Test1", "Test2"),
    email = c("damien.dupre@dcu.ie", "test.1@gmail.com", "test.2@gmail.com"),
    assignment_paper_url = c("paper 0", "paper 2", "paper 2"),
    assignment_data_url = c("data 0", "data 2", "data 2")
  ) # check in email sent box if they have been successfully sent 

# data student -----------------------------------------------------------------
data_students <- file.choose() |>  
  read_csv() |> 
  clean_names()

################################################################################
data_students |>
  mutate(
    email_content = glue(email_body),
    email_send = map2(
      .x = email, 
      .y = email_content, 
      ~smtp_send(
        compose_email(body = md(.y)) |> 
          add_attachment(file = here(glue("21-22_students/assignment/{str_extract(string = .x, pattern = '[^.]+')}/mt611_assignment_data_cleaned.csv"))),
        subject = "MT611 - Assignment Instructions and Data - Confirm Reception",
        from = "damien.dupre@dcu.ie",
        to = .x,
        credentials = creds_key("gmail")
      )
    )
  )
