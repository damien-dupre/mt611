# 
# https://ia803207.us.archive.org/18/items/TheMakingOfIslamicScienceByMuzaffarIqbal/TheMakingOfIslamicScienceByMuzaffarIqbal_djvu.txt
# https://ia801309.us.archive.org/0/items/PrintWhatYouLikeOnScholarlyTraditionsOfTheSchoolsInBaghdadTheMustansiriaAsAModelMuslimHeritage/Al-Jazari_%20The%20Mechanical%20Genius%20_%20Muslim%20Heritage_djvu.txt
# https://ia801602.us.archive.org/18/items/GeorgeSalibaIslamicScienceAndTheMakingOfTheEuropeanRenaissanceTransformationsStu/George%20Saliba-Islamic%20Science%20and%20the%20Making%20of%20the%20European%20Renaissance%20%28Transformations_%20Studies%20in%20the%20History%20of%20Science%20and%20Tec_djvu.txt
# https://ia801302.us.archive.org/2/items/TheEnterpriseOfScienceInIslamByHogendijkAndSabra/The%20Enterprise%20ofScience%20in%20Islam%20by%20Hogendijk%20and%20Sabra_djvu.txt
# https://ia600109.us.archive.org/9/items/IslamicContributionsToCivilizationStanwoodCobb/Islamic%20Contributions%20to%20Civilization%20Stanwood%20Cobb_djvu.txt
# https://ia902801.us.archive.org/30/items/TheDevelopmentOfTheArabicScriptsFromTheNabateanEraToTheFirstIslamicCentury/The%20Development%20of%20the%20Arabic%20Scripts%20From%20the%20Nabatean%20Era%20to%20the%20First%20Islamic%20Century_djvu.txt
# https://ia802708.us.archive.org/17/items/NarrativesOfIslamicOriginsTheBeginningsOfIslamicHistoricalWriting/Narratives%20of%20Islamic%20Origins-%20The%20Beginnings%20of%20Islamic%20Historical%20Writing_djvu.txt
# https://ia903207.us.archive.org/18/items/TheMakingOfIslamicScienceByMuzaffarIqbal/TheMakingOfIslamicScienceByMuzaffarIqbal_djvu.txt
# https://ia801608.us.archive.org/5/items/RoshdiRasheded.EncyclopediaOfTheHistoryOfArabicScienceVol.3Routledge1996/Qisar-Roshdi-Rashed-Encyclopedia-of-the-History-of-Arabic-Science_djvu.txt
# https://ia801303.us.archive.org/27/items/HistoryOfScienceAndTechnologyInIslam/History%20of%20Science%20and%20Technology%20in%20Islam_djvu.txt
# # load packages
library(tidyverse)
library(quanteda)
library(tidytext)
library(tm)
library(DT)
# read in text
txt_raw <- readLines("https://slcladal.github.io/data/origindarwin.txt") %>%
  paste(sep = " ", collapse = " ") %>%
  stringr::str_squish() %>%
  stringr::str_remove_all("- ")
# further processing
txt_tidy <- txt_raw %>% 
  as_tibble() %>%
  tidytext::unnest_tokens(words, value)
# create data frame
txt_lag <- txt_tidy %>%
  dplyr::rename(word1 = words) %>%
  dplyr::mutate(word2 = c(word1[2:length(word1)], NA)) %>%
  na.omit()

txt_freq_2grams <- txt_lag %>%
  dplyr::mutate(bigram = paste(word1, word2, sep = " ")) %>%
  dplyr::group_by(bigram) %>%
  dplyr::summarise(frequency = n()) %>%
  dplyr::arrange(-frequency)

# define stopwords
stps <- paste0(tm::stopwords(kind = "en"), collapse = "\\b|\\b")
# clean bigram table
txt_2grams_freq <- txt_freq_2grams %>%
  dplyr::filter(!str_detect(bigram, stps))

#clean corpus
txt_tokzd <- txt_raw %>%
  stringr::str_to_title() %>% 
  quanteda::tokens()
# extract bigrams
txt_2grams_stats <- txt_tokzd %>% 
  quanteda::tokens_remove(stopwords("en")) %>% 
  quanteda::tokens_select(
    pattern = "^[A-Z]", 
    valuetype = "regex",
    case_insensitive = FALSE, 
    padding = TRUE
  ) %>% 
  quanteda.textstats::textstat_collocations(min_count = 5, tolower = FALSE)

# ngram_extract <- quanteda::tokens_compound(txt_tokzd, pattern = txt_2grams_stats)
# head(kwic(ngram_extract, pattern = c("Natural_Selection", "South_America")), 15)
# Finding Collocations
# read in text
txt_sentences <- txt_raw %>%
  stringr::str_squish() %>%
  stringr::str_replace_all("([A-Z]{2,} [A-Z]{2,}) ([A-Z][a-z]{1,} )", "\\1 qwertz\\2") %>%
  stringr::str_replace_all("([a-z]{2,}\\.) ([A-Z] {0,1}[a-z]{0,30})", "\\1qwertz\\2") %>%
  stringr::str_replace_all("([a-z]{2,}\\?) ([A-Z] {0,1}[a-z]{0,30})", "\\1qwertz\\2") %>%
  strsplit("qwertz")%>%
  unlist() %>%
  stringr::str_remove_all("- ") %>%
  stringr::str_replace_all("\\W", " ") %>%
  stringr::str_squish()
#convert into corpus
txt_corpus <- Corpus(VectorSource(txt_sentences))
# create vector with words to remove
extrawords <- c("the", "can", "get", "got", "can", "one", 
                "dont", "even", "may", "but", "will", 
                "much", "first", "but", "see", "new", 
                "many", "less", "now", "well", "like", 
                "often", "every", "said", "two")
# clean corpus
txt_corpus_clean <- txt_corpus %>%
  tm::tm_map(removePunctuation) %>%
  tm::tm_map(removeNumbers) %>%
  tm::tm_map(tolower) %>%
  tm::tm_map(removeWords, stopwords()) %>%
  tm::tm_map(removeWords, extrawords)
# create document term matrix
txt_dtm <- DocumentTermMatrix(txt_corpus_clean, control=list(bounds = list(global=c(1, Inf)), weighting = weightBin))
# load library
library(Matrix)
# convert dtm into sparse matrix
txt_dtm <- sparseMatrix(i = txt_dtm$i, j = txt_dtm$j, 
                           x = txt_dtm$v, 
                           dims = c(txt_dtm$nrow, txt_dtm$ncol),
                           dimnames = dimnames(txt_dtm))
# calculate co-occurrence counts
coocurrences <- t(txt_dtm) %*% txt_dtm
# convert into matrix
collocates <- as.matrix(coocurrences)
# load function for co-occurrence calculation
source("https://slcladal.github.io/rscripts/calculateCoocStatistics.R")
# define term
coocTerm <- "evolution"
# calculate cooccurence statistics
coocs <- calculateCoocStatistics(coocTerm, txt_dtm, measure="LOGLIK")
coocdf <- coocs %>%
  as.data.frame() %>%
  dplyr::mutate(CollStrength = coocs,
                Term = names(coocs)) %>%
  dplyr::filter(CollStrength > 0)
# plot
ggplot(coocdf, aes(x = reorder(Term, CollStrength, mean), y = CollStrength)) +
  geom_point() +
  coord_flip() +
  theme_bw()

ggplot(txt_2grams_stats, aes(x = lambda, y = z)) +
  geom_point() +
  theme_bw()

################################################################################
twograms_collocations_stats <- function(book_path) {
  readLines(book_path) %>%
    paste(sep = " ", collapse = " ") %>%
    stringr::str_squish() %>%
    stringr::str_remove_all("- ") %>%
    stringr::str_to_title() %>% 
    quanteda::tokens() %>% 
    quanteda::tokens_remove(stopwords("en")) %>% 
    quanteda::tokens_select(
      pattern = "^[A-Z]", 
      valuetype = "regex",
      case_insensitive = FALSE, 
      padding = TRUE
    ) %>% 
    quanteda.textstats::textstat_collocations(min_count = 5, tolower = FALSE)
}

test <- twograms_collocations_stats("https://ia801602.us.archive.org/18/items/GeorgeSalibaIslamicScienceAndTheMakingOfTheEuropeanRenaissanceTransformationsStu/George%20Saliba-Islamic%20Science%20and%20the%20Making%20of%20the%20European%20Renaissance%20%28Transformations_%20Studies%20in%20the%20History%20of%20Science%20and%20Tec_djvu.txt")
ggplot(test, aes(x = lambda, y = z)) +
  geom_point() +
  theme_bw()
################################################################################

corpus_book <- data.frame(
  book_url = c(
    "https://slcladal.github.io/data/origindarwin.txt",
    "https://ia803207.us.archive.org/18/items/TheMakingOfIslamicScienceByMuzaffarIqbal/TheMakingOfIslamicScienceByMuzaffarIqbal_djvu.txt",
    "https://ia801309.us.archive.org/0/items/PrintWhatYouLikeOnScholarlyTraditionsOfTheSchoolsInBaghdadTheMustansiriaAsAModelMuslimHeritage/Al-Jazari_%20The%20Mechanical%20Genius%20_%20Muslim%20Heritage_djvu.txt",
    "https://ia801602.us.archive.org/18/items/GeorgeSalibaIslamicScienceAndTheMakingOfTheEuropeanRenaissanceTransformationsStu/George%20Saliba-Islamic%20Science%20and%20the%20Making%20of%20the%20European%20Renaissance%20%28Transformations_%20Studies%20in%20the%20History%20of%20Science%20and%20Tec_djvu.txt",
    "https://ia801302.us.archive.org/2/items/TheEnterpriseOfScienceInIslamByHogendijkAndSabra/The%20Enterprise%20ofScience%20in%20Islam%20by%20Hogendijk%20and%20Sabra_djvu.txt",
    "https://ia600109.us.archive.org/9/items/IslamicContributionsToCivilizationStanwoodCobb/Islamic%20Contributions%20to%20Civilization%20Stanwood%20Cobb_djvu.txt",
    "https://ia902801.us.archive.org/30/items/TheDevelopmentOfTheArabicScriptsFromTheNabateanEraToTheFirstIslamicCentury/The%20Development%20of%20the%20Arabic%20Scripts%20From%20the%20Nabatean%20Era%20to%20the%20First%20Islamic%20Century_djvu.txt",
    "https://ia802708.us.archive.org/17/items/NarrativesOfIslamicOriginsTheBeginningsOfIslamicHistoricalWriting/Narratives%20of%20Islamic%20Origins-%20The%20Beginnings%20of%20Islamic%20Historical%20Writing_djvu.txt",
    "https://ia903207.us.archive.org/18/items/TheMakingOfIslamicScienceByMuzaffarIqbal/TheMakingOfIslamicScienceByMuzaffarIqbal_djvu.txt",
    "https://ia801608.us.archive.org/5/items/RoshdiRasheded.EncyclopediaOfTheHistoryOfArabicScienceVol.3Routledge1996/Qisar-Roshdi-Rashed-Encyclopedia-of-the-History-of-Arabic-Science_djvu.txt",
    "https://ia801303.us.archive.org/27/items/HistoryOfScienceAndTechnologyInIslam/History%20of%20Science%20and%20Technology%20in%20Islam_djvu.txt"
  )
)

corpus_book <- read_csv("/Users/damiendcu/Desktop/mohammad_corpus.csv")

corpus_stats <- corpus_book %>% 
  group_by(book_url) %>%      
  summarise(twograms_collocations_stats(book_url))

corpus_stats <- corpus_stats %>% 
  full_join(corpus_book) %>% 
  write_csv("mohammad_assignment.csv")


ggplot(corpus_stats, aes(x = count, y = lambda)) +
  geom_point() +
  theme_bw()
