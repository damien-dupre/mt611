################################################################################
#                        Data Simulation Students                              #
################################################################################

# libraries --------------------------------------------------------------------
library(tidyverse)
library(tabulizer)
library(here)
library(janitor)
library(snakecase)
library(faux)
library(magrittr)
# functions --------------------------------------------------------------------
rtruncnorm <- function(N, mean = 0, sd = 1, a = -Inf, b = Inf) {
  U <- runif(N, pnorm(a, mean, sd), pnorm(b, mean, sd))
  qnorm(U, mean, sd) 
}

# Akanksha #####################################################################
Akanksha_df <- 
  tibble::tribble(
    ~variable, ~communale_targets_Male_M, ~communale_targets_Male_SD,
    ~communale_targets_Female_M, ~communale_targets_Female_SD, ~communale_targets_d, ~agentic_targets_Male_M, ~agentic_targets_Male_SD,
    ~agentic_targets_Female_M, ~agentic_targets_Female_SD, ~agentic_targets_d,
    "Competence", 5.35, 0.78, 5.26, 0.74, 0.12, 5.34, 0.64, 5.17, 0.84, 0.23,
    "Liking", 4.18, 1.45, 4.16, 1.06, 0.01, 3.78, 1.34, 2.53, 1.16, 0.88,
    "Hireability", 5.03, 1.11, 4.91, 0.96, 0.11, 4.90, 0.89, 4.11, 1.22, 0.72,
    "Stereotypes_Agentic", 5.74, 0.66, 5.75, 0.79, -0.01, 5.91, 0.63, 6.03, 0.58, -0.18,
    "Stereotypes_Communal", 4.62, 0.97, 4.54, 1.13, 0.07, 3.52, 0.92, 3.62, 0.70, -0.09,
    "Stereotypes_Weak", 2.27, 0.60, 2.32, 0.74, -0.06, 2.13, 0.77, 2.09, 0.90, 0.05,
    "Stereotypes_Dominant", 3.15, 1.00, 3.34, 1.16, -0.13, 4.94, 1.24, 5.48, 0.88, -0.37
  ) %>%
  select(-communale_targets_d, -agentic_targets_d) %>%
  pivot_longer(-variable, names_to = "measures") %>%
  separate(measures, c("condition", "type", "gender", "metric")) %>% 
  unite("condition_type", condition:type) %>%
  pivot_wider(names_from = metric, values_from = value) %>%
  group_by(variable, condition_type, gender) %>%
  summarise(value = rnorm(100, mean = M, sd = SD)) %>% 
  ungroup() %>% 
  arrange(variable) %>% 
  mutate(participant = rep(1:400,7)) %>% 
  pivot_wider(names_from = variable, values_from = value) %>% 
  select(participant, everything()) %>% 
  write_csv(here("20-21_students/sim_data/Akanksha_df.csv"))
# Anish ########################################################################
tab <- 
  extract_tables(
    here("20-21_students/student_ref_paper/Anish.pdf"), 
    pages = 10, 
    output = "data.frame"
  )[[1]] %>% 
  remove_empty("cols") %>% 
  clean_names() %>% 
  select(-6)

Related_merger <- tab %>% 
  select(variable = variable_name, metric = mean_median, sd = standard_deviation) %>% 
  slice(2:10) %>% 
  mutate(type = "Related_merger")

Unrelated_merger <- tab %>% 
  select(variable = variable_name, metric = mean_median_1, sd = standard_deviation_1) %>% 
  slice(2:10) %>% 
  mutate(type = "Unrelated_merger")

Nonrescue_merger <- tab %>% 
  select(variable = variable_name, metric = mean_median, sd = standard_deviation) %>% 
  slice(12:20) %>% 
  mutate(type = "Nonrescue_merger")

Rescue_merger <- tab %>% 
  select(variable = variable_name, metric = mean_median_1, sd = standard_deviation_1) %>% 
  slice(12:20) %>% 
  mutate(type = "Rescue_merger")

Anish_df <- 
  bind_rows(
    Related_merger,
    Unrelated_merger,
    Nonrescue_merger,
    Rescue_merger
  ) %>% 
  mutate(
    variable = 
      to_snake_case(variable) %>% 
      if_else(. == "wagegrowtht_3", "wage_growtht_3", .)
  ) %>% 
  separate(metric, sep =" ", c("m", "med")) %>% 
  select(-med) %>%
  mutate(across(c("m", "sd"), as.numeric)) %>% 
  group_by(variable, type) %>%
  summarise(value = rnorm(100, mean = m, sd = sd)) %>% 
  ungroup() %>% 
  arrange(variable) %>% 
  mutate(organisation = rep(1:400, 9)) %>% 
  pivot_wider(names_from = variable, values_from = value) %>% 
  write_csv(here("20-21_students/sim_data/Anish_df.csv"))
# Emma #########################################################################
Emma_df <- 
  extract_tables(
    here("20-21_students/student_ref_paper/Emma.pdf"), 
    pages = 7, 
    output = "data.frame"
  )[[1]] %>% 
  row_to_names(1) %>% 
  clean_names() %>% 
  select(-p_value)

BIRS_Total <- Emma_df %>% 
  slice(4:6) %>% 
  mutate(
    scale = "BIRS",
    variable = "Total"
  )
BIRS_Strength_and_health <- Emma_df %>% 
  slice(8:10) %>% 
  mutate(
    scale = "BIRS",
    variable = "Strength_and_health"
  )
BIRS_Social_barriers <- Emma_df %>% 
  slice(12:14) %>% 
  mutate(
    scale = "BIRS",
    variable = "Social_barriers"
  )
BIRS_Appearance_and_sexuality <- Emma_df %>% 
  slice(16:18) %>% 
  mutate(
    scale = "BIRS",
    variable = "Appearance_and_sexuality"
  )
SF36_Mental_composite <- Emma_df %>% 
  slice(21:23) %>% 
  mutate(
    scale = "SF36",
    variable = "Mental_composite"
  )
SF36_Physical_composite <- Emma_df %>% 
  slice(25:27) %>% 
  mutate(
    scale = "SF36",
    variable = "Physical_composite"
  )
Strength_1RM_Bench_press <- Emma_df %>% 
  slice(30:32) %>% 
  mutate(
    scale = "Strength_1RM",
    variable = "Bench_press"
  )
Strength_1RM_Leg_press <- Emma_df %>% 
  slice(34:37) %>% 
  mutate(
    scale = "Strength_1RM",
    variable = "Leg_press"
  )
Emma_df <- 
  bind_rows(
    BIRS_Total,
    BIRS_Strength_and_health,
    BIRS_Social_barriers,
    BIRS_Appearance_and_sexuality,
    SF36_Mental_composite,
    SF36_Physical_composite,
    Strength_1RM_Bench_press,
    Strength_1RM_Leg_press
  ) %>% 
  mutate(
    value_1 = str_replace(variable_tx, "No LE", "No_LE"),
    value_2 = str_replace(control, "\\(", " \\(") %>% str_replace("  \\(", " \\(")
  ) %>% 
  select(-variable_tx, -control) %>% 
  separate(value_1, c("condition", "tx12_n", "tx12_m", "tx12_sd"), sep = " ") %>% 
  separate(value_2, c(NA, NA, "control12_n", "control12_m", "control12_sd", NA, NA), sep = " ") %>% 
  filter(condition != "All") %>% 
  pivot_longer(
    cols = -(scale:condition),
    names_to = "metric",
    values_to = "value"
  ) %>% 
  mutate(value = parse_number(value)) %>% 
  separate(metric, c("type", "metric")) %>% 
  pivot_wider(names_from = metric, values_from = value) %>% 
  group_by(scale, variable, condition, type) %>%
  summarise(value = rnorm(n, mean = m, sd = sd)) %>% 
  group_by(scale, variable) %>%
  mutate(
    value = round(value, 0),
    participant = row_number()
  ) %>% 
  ungroup() %>% 
  pivot_wider(names_from = c("scale", "variable")) %>% 
  write_csv(here("20-21_students/sim_data/Emma_df.csv"))
# Laura ########################################################################
Laura_df <- 
  data.frame(
    device = sample(c("VR","PC"), 100, replace = TRUE),
    scent = sample(c("no_scent", "pleasant_noncongruent", "pleasant_congruent"), 100, replace = TRUE),
    prev_exp_destination = rtruncnorm(100, 5, 2, 1, 7),
    pref_type_tourism = rtruncnorm(100, 5, 2, 1, 7),
    prev_exp_360 = rtruncnorm(100, 5, 2, 1, 7),
    prev_exp_VR = rtruncnorm(100, 5, 2, 1, 7)
  ) %>% 
  mutate(
    across(where(is.numeric), round),
    across(where(is.character), as.factor),
    sensory_stimulation = 3.228 + 1.434 * as.numeric(device) + 0.961 * as.numeric(scent) + 0.297 * prev_exp_destination + 0.043 * pref_type_tourism + 0.041 * prev_exp_360 - 0.321 * prev_exp_VR,
    ease_imagination = 1.705 + 0.124 * as.numeric(device) + 0.523 * as.numeric(scent) + 0.028 * prev_exp_destination + 0.163 * pref_type_tourism + 0.041 * prev_exp_360 + 0.138 * prev_exp_VR,
    affective_image = 1.395 - 0.140 * as.numeric(device) + 0.262 * sensory_stimulation + 0.438 * ease_imagination - 0.171 * prev_exp_destination + 0.078 * pref_type_tourism + 0.030 * prev_exp_360 - 0.038 * prev_exp_VR,
    conative_image = 0.363 - 0.294 * as.numeric(device) +  0.170 * sensory_stimulation + 0.637 * ease_imagination - 0.182 * prev_exp_destination + 0.040 * pref_type_tourism + 0.123 * prev_exp_360 - 0.316 * prev_exp_VR,
  ) %>% 
  write_csv(here("20-21_students/sim_data/Laura_df.csv"))
# Lorna ########################################################################
Lorna_df <- 
  data.frame(
    gender = sample(c("male","female"), 1000, replace = TRUE),
    age = rnorm(1000, 16.7, 1.42) %>% round,
    offer = sample(c("yes","no"), 1000, replace = TRUE, prob = c(25, 75)),
    consumed = sample(c("yes","no"), 1000, replace = TRUE, prob = c(60, 40)),
    level = sample(c("Experimental","Occasional", "Repeated","Regular", "Intensive"), 1000, replace = TRUE, prob = c(25, 35, 20, 10, 10)),
    PNTP = rtruncnorm(1000, 5, 2, 1, 7),
    PHTP = rtruncnorm(1000, 3, 2, 1, 7),
    FTP = rtruncnorm(1000, 6, 1.5, 1, 7),
    PPTP = rtruncnorm(1000, 2, 3, 1, 7),
    DCS = rtruncnorm(1000, 5.5, 1.7, 1, 7)
  ) %>% 
  mutate(
    Attitude = -0.03 * as.numeric(as.factor(gender)) + 0.14 * age - 0.1 * PNTP + 0.23 * PHTP - 0.17 * FTP - 0.11 * PPTP - 0.04 * DCS + 4,
    Subjective_Norm = -0.01 * as.numeric(as.factor(gender)) + 0.07 * age - 0.1 * PNTP + 0.19 * PHTP - 0.1 * FTP - 0.04 * PPTP - 0.05 * DCS + 3.5,
    Perceived_Control = -0.06 * as.numeric(as.factor(gender)) + 0.13 * age - 0.3 * PNTP + 0.27 * PHTP - 0.19 * FTP - 0.07 * PPTP + 0.05 * DCS + 3,
  ) %>% 
  write_csv(here("20-21_students/sim_data/Lorna_df.csv"))
# Mohammad #####################################################################
Mohammad_df <- tibble::tribble(
                                                   ~data,
          "sure 6.80 7.09 7.26 5.78 6.90 6.64 6.26 6.92",
      "decision 4.55 3.67 4.07 5.86 6.12 7.91 7.57 8.07",
         "point 3.44 2.92 3.84 3.68 4.11 3.12 3.01 3.93",
  "sure 74.52 13.58 21.45 32.24 28.59 16.92 18.36 22.31",
  "decision 27.59 9.44 9.22 10.45 11.58 5.08 6.82 10.82",
      "point 27.41 9.50 7.78 35.61 13.78 3.43 4.20 6.47",
      "sure 9.63 7.60 9.52 9.61 10.68 10.17 10.07 10.61",
      "decision 6.91 6.61 7.16 6.62 8.31 7.05 7.60 8.87",
         "point 6.90 6.65 6.74 6.55 8.52 6.03 6.30 7.30"
  ) %>% 
  separate(data, c("word", "BNC", "BNC_A", "BNC_N", "BNC_F", "BNC_CG", "BNC_D", "BNC_SP", "CANC"), sep = " ") %>% 
  mutate(
    across(-word, as.numeric),
    metric = c(rep("MI-score", 3), rep("t-score", 3), rep("Log Dice", 3))
  ) %>% 
  write_csv(here("20-21_students/sim_data/Mohammad_df.csv"))
# RichardH #####################################################################
RichardH_df <- 
  tribble(
  ~variable_1, ~m, ~sd, ~Servant_leadership, ~Initiating_structure, ~Creative_behavior, ~Deviant_behavior, ~Inrole_performance, ~Helping_behaviors, ~WRF_promotion, ~WRF_prevention, ~RFQ_promotion, ~RFQ_prevention, ~Positive_affectivity, ~Negative_affectivity,
    "Servant_leadership", 3.42, 0.93, 1, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
    "Initiating_structure", 3.60, 0.88, 0.58, 1, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
    "Creative_behavior", 3.55, 0.90, 0.37, 0.22, 1, NA, NA, NA, NA, NA, NA, NA, NA, NA,
    "Deviant_behavior", 1.74, 0.80, 0.08, 0.23, 0.00, 1, NA, NA, NA, NA, NA, NA, NA, NA,
    "Inrole_performance", 4.49, 0.58, 0.01, 0.17, 0.08, 0.48, 1,  NA, NA, NA, NA, NA, NA, NA,
    "Helping_behaviors", 3.90, 0.86, 0.37, 0.29, 0.47, 0.24, 0.31, 1,  NA, NA, NA, NA, NA, NA,
    "WRF_promotion", 3.64, 0.76, 0.48, 0.45, 0.51, 0.18, 0.18, 0.52, 1,  NA, NA, NA, NA, NA,
    "WRF_prevention", 4.13, 0.65, 0.32, 0.44, 0.17, 0.30, 0.36, 0.33, 0.52, 1,  NA, NA, NA, NA,
    "RFQ_promotion", 3.72, 0.67, 0.24, 0.28, 0.32, 0.37, 0.39, 0.37, 0.39, 0.37, 1,  NA, NA, NA,
    "RFQ_prevention", 3.29, 0.86, 0.00, 0.01, 0.08, 0.24, 0.11, 0.09, 0.03, 0.09, 0.29, 1, NA, NA,
    "Positive_affectivity", 3.70, 0.80, 0.32, 0.31, 0.52, 0.29, 0.27, 0.46, 0.57, 0.41, 0.66, 0.16, 1,  NA,
    "Negative_affectivity", 4.08, 0.71, 0.13, 0.19, 0.17, 0.38, 0.26, 0.19, 0.11, 0.18, 0.51, 0.23, 0.47, 1
  )

temp_1 <- RichardH_df %>% 
  select(variable_1, m, sd)

temp_2 <- RichardH_df %>% 
  pivot_longer(-c("variable_1", "m", "sd"), "variable_2") %>% 
  drop_na() %>% 
  select(-c("m", "sd"))

temp_3 <- temp_2 %>% 
  filter(variable_1 != variable_2) %>% 
  rename(variable_1 = variable_2, variable_2 = variable_1) %>% 
  bind_rows(temp_2) %>% 
  pivot_wider(names_from = variable_2, values_from = value) %>% 
  column_to_rownames("variable_1") %>% 
  select(Servant_leadership, everything()) %>% 
  as.matrix()

RichardH_df <- 
  rnorm_multi(
    n = 250, 
    vars = 12, 
    mu = temp_1$m, 
    sd = temp_1$sd, 
    r = temp_3,
    varnames = colnames(temp_3)
  ) %>% 
  mutate(
    gender = sample(c("male","female"), 250, replace = TRUE, prob = c(68, 32)),
    age = rtruncnorm(250, mean = 40, sd = 15, a = 18, b = 66) %>% round
  ) %>% 
  write_csv(here("20-21_students/sim_data/RichardH_df.csv"))
# RichardNB ####################################################################
RichardNB_df <- 
  extract_tables(
    here("20-21_students/student_ref_paper/RichardNB.pdf"), 
    pages = 20, 
    output = "data.frame"
  )[[1]] %>% 
  remove_empty("cols") %>% 
  clean_names() %>% 
  rename(variable = variable_mean) %>% 
  mutate(across(where(is.character), str_replace_all, "−", "-"))

CHA_word_count <- RichardNB_df %>% 
  slice(2:6) %>% 
  mutate(type = "CHA_word_count")
CHA_disclosure_index <- RichardNB_df %>% 
  slice(8:12) %>% 
  mutate(type = "CHA_disclosure_index")
CG_variables <- RichardNB_df %>% 
  slice(14:20) %>% 
  mutate(type = "CG_variables")
FV_variables <- RichardNB_df %>% 
  slice(22:24) %>% 
  mutate(type = "FV_variables")
firm_level_characteristics <- RichardNB_df %>% 
  slice(26:34) %>% 
  mutate(type = "firm_level_characteristics")

RichardNB_df <- 
  bind_rows(
    CHA_word_count,
    CHA_disclosure_index,
    CG_variables,
    FV_variables,
    firm_level_characteristics
  ) %>% 
  mutate(
    mean = variable,
    across(-c(variable, type), parse_number),
    variable = str_replace_all(variable, "[:digit:]", "") %>% make_clean_names
  ) %>% 
  group_by(variable, type) %>% 
  summarise(value = rtruncnorm(500, mean, std_dev, minimum, maximum)) %>%
  mutate(
    value = round(value),
    firm = row_number()
  ) %>% 
  ungroup() %>% 
  unite("variable", c(type, variable)) %>% 
  pivot_wider(names_from = variable, values_from = value) %>% 
  write_csv(here("20-21_students/sim_data/RichardNB_df.csv"))

RichardNB_df <- 
  tibble(
    foreign_experience = sample(c(0,1), 13840, replace = TRUE, prob = c(91.9, 8.1)),
    foreign_ownership = rpois(13840, 0.77),
    block = sample(c(0,1), 13840, replace = TRUE, prob = c(59.7, 40.3)),
    state = sample(c(0,1), 13840, replace = TRUE, prob = c(29.7, 70.3)),
    size = rpois(13840, 9.448),
    leverage = sample(c(0,1), 13840, replace = TRUE, prob = c(50, 50)),
    no_of_business_segments = rpois(13840, 2.199),
    free_fash_flow = rnorm(13840, -0.014, 0.093),
    young_ipo_firm = sample(c(0,1), 13840, replace = TRUE, prob = c(73.1, 26.9)),
    stock_volatility = rnorm(13840, 0.034, 0.021)
  ) %>% 
  mutate(roe = 
           foreign_experience * 0.805 +
           foreign_ownership * 0.376 +
           block * 0.545 +
           state * -0.127 +
           size * -0.524 +
           leverage * 0.231 +
           no_of_business_segments * -0.028 +
           free_fash_flow * 0.979 +
           young_ipo_firm * -0.142 +
           stock_volatility * 5.774
  )  %>% 
  write_csv(here("20-21_students/sim_data/RichardNB_df.csv"))
# Sian #########################################################################
Sian_df <-  
  extract_tables(
    here("20-21_students/student_ref_paper/Sian.pdf"), 
    pages = 10, 
    output = "data.frame"
  )[[2]] %>% 
  clean_names() %>% 
  separate(variable, c(NA, "variable_1"), sep = "[.] ") %>% 
  mutate(
    across(everything(), as.character),
    across(-variable_1, parse_number),
    variable_1 = make_clean_names(variable_1)
  )

temp_1 <- select(Sian_df, -c(mean, sd))  %>% 
  set_colnames(c("variable_1", Sian$variable)) %>% 
  pivot_longer(-variable_1, "variable_2") %>% 
  mutate(
    value = if_else(variable_1 == variable_2, 1, value),
    value = if_else(value > 1, (value - 2) * -1, value)
  ) %>% 
  drop_na()

temp_2 <- temp_1 %>% 
  filter(variable_1 != variable_2) %>% 
  rename(variable_1 = variable_2, variable_2 = variable_1) %>% 
  bind_rows(temp_1) %>% 
  pivot_wider(names_from = variable_2, values_from = value) %>% 
  column_to_rownames("variable_1") %>% 
  select(feeling_trusted, everything()) %>% 
  as.matrix()

Sian_df <- 
  rnorm_multi(
    n = 219, 
    vars = 6, 
    mu = Sian_df$mean, 
    sd = Sian_df$sd, 
    r = temp_2,
    varnames = Sian_df$variable
  ) %>% 
  mutate(
    gender = sample(c("male","female"), 219, replace = TRUE, prob = c(94, 6)),
    age = rtruncnorm(219, mean = 46, sd = 10.42, a = 18, b = 66) %>% round,
    experience = rtruncnorm(219, mean = 7.93, sd = 7.91, a = 1, b = Inf) %>% round
  ) %>% 
  write_csv(here("20-21_students/sim_data/Sian_df.csv"))
